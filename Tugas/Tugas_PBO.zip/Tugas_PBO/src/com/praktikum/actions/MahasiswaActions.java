package com.praktikum.actions;

public interface MahasiswaActions {
    // Aksi untuk melaporkan barang
    void reportItem();

    // Aksi untuk melihat daftar barang
    void viewReportedItems();
}

