package com.praktikum.actions;

public interface AdminActions {
    // Aksi untuk mengelola barang
    void manageItems();

    // Aksi untuk mengelola data mahasiswa
    void manageUsers();
}

