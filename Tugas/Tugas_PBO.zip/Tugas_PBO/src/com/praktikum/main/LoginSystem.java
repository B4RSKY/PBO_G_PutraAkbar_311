package com.praktikum.main;

import com.praktikum.gui.MainApp;

public class LoginSystem {
    public static void main(String[] args) {
        // Launch JavaFX Application
        MainApp.launch(MainApp.class, args);
    }
}